﻿using Application.CurrencyExchange.Comands;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CurrencyExchange : BaseApiController<CurrencyExchange>
    {
        [HttpGet]
        [Route("Currencies")]
        public async Task<IActionResult> Get()
        {
            GetCurrencyCommand command = new GetCurrencyCommand();
            return Ok(await _mediator.Send(command));
        }


        [HttpGet]
        [Route("GetByBaseCurrency")]
        public async Task<IActionResult> GetByBaseCurrency([FromQuery]GetCurrenciesByBaseCurrencyCommand command)
        {
            return Ok(await _mediator.Send(command));
        }

        [HttpGet]
        [Route("GetCurrenciesByNDaysAgo")]
        public async Task<IActionResult> GetCurrenciesByDays([FromQuery] GetCurrenciesByDaysCommand command)
        {
            return Ok(await _mediator.Send(command));
        }

        [HttpPost]
        [Route("CurrencyConvert")]
        public async Task<IActionResult> CurrencyConvert(CurrencyConversionCommand command)
        {
            return Ok(await _mediator.Send(command));
        }

    }
}
