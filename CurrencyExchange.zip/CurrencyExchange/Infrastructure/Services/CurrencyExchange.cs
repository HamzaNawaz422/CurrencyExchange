﻿using Application.CurrencyExchange.Models;
using Application.Interfaces;
using Application.Wrapper;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.Services
{
    public class CurrencyExchange: ICurrencyExchange
    {
        public async Task<GetAllCurrenciesReadModel> GetLatestCurrencies()
        {
            var currencies = new GetAllCurrenciesReadModel();
            try
            {
                var client = new RestClient("https://api.apilayer.com/exchangerates_data/latest");
                client.Timeout = -1;
                var request = new RestRequest(Method.GET);
                request.AddHeader("apikey", "f1XC7eVEvP6D4OSSpDQwS6byCI74fiHt");

                var response =  await client.ExecuteGetAsync<GetAllCurrenciesReadModel>(request);
                var res= response.Data;
                return res;
                //IRestResponse response = client.Execute(request);

            }
            catch (Exception ex)
            {
            }
            return currencies;
        }



        public async Task<GetAllCurrenciesReadModel> GetCurrenciesByBaseCurrency(string baseCurrency)
        {
            var currencies = new GetAllCurrenciesReadModel();
            try
            {
                var endpoint = $"https://api.apilayer.com/exchangerates_data/latest?base={baseCurrency}";

                var client = new RestClient(endpoint);
                client.Timeout = -1;
                var request = new RestRequest(Method.GET);
                request.AddHeader("apikey", "f1XC7eVEvP6D4OSSpDQwS6byCI74fiHt");
               

                var response = await client.ExecuteGetAsync<GetAllCurrenciesReadModel>(request);
                var res = response.Data;
                return res;
                //IRestResponse response = client.Execute(request);

            }
            catch (Exception ex)
            {
            }
            return currencies;
        }



        public async Task<GetAllCurrenciesReadModel> GetCurrenciesByNDaysAgo(int days)
        {
            var currencies = new GetAllCurrenciesReadModel();
            try
            {
                var dateTime = DateTime.Now.AddDays(-days).ToString("yyyy-MM-dd");
                var endpoint = $"https://api.apilayer.com/exchangerates_data/{dateTime}";

                var client = new RestClient(endpoint);
                client.Timeout = -1;
                var request = new RestRequest(Method.GET);
                request.AddHeader("apikey", "f1XC7eVEvP6D4OSSpDQwS6byCI74fiHt");

                var response = await client.ExecuteGetAsync<GetAllCurrenciesReadModel>(request);
                var res = response.Data;
                return res;
                //IRestResponse response = client.Execute(request);

            }
            catch (Exception ex)
            {
            }
            return currencies;
        }



        public async Task<CurrencyConvertReadModel> GetCurrencyConversion(CurrencyConvertRequestModel requestModel)
        {
            var currencies = new CurrencyConvertReadModel();
            try
            {

                var endpoint = $"https://api.apilayer.com/exchangerates_data/convert?to={requestModel.ToCurrency}&from={requestModel.FromCurrency}&amount={requestModel.Value}";


                var client = new RestClient(endpoint);
                client.Timeout = -1;
                var request = new RestRequest(Method.GET);
                request.AddHeader("apikey", "f1XC7eVEvP6D4OSSpDQwS6byCI74fiHt");
                
                var apiResponse = await client.ExecuteGetAsync<APIResponseModel>(request);

                var response = new CurrencyConvertReadModel
                {
                    BaseValue = apiResponse.Data.Query.Amount,
                    FromCurrency=apiResponse.Data.Query.From,
                    ToCurrency=apiResponse.Data.Query.To,
                    Result=apiResponse.Data.Result
                };


                return response;
                //IRestResponse response = client.Execute(request);

            }
            catch (Exception ex)
            {
            }
            return currencies;
        }
    }
}
