﻿using Application.CurrencyExchange.Models;
using Application.Interfaces;
using Application.Wrapper;
using MediatR;
using Microsoft.Extensions.Localization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.CurrencyExchange.Comands
{
    public class GetCurrencyCommand : IRequest<Result<GetAllCurrenciesReadModel>>
    {

        //public string CurrencyTo { get; set; }


    }


    public class GetCurrencyCommandHandler : IRequestHandler<GetCurrencyCommand, Result<GetAllCurrenciesReadModel>>
    {
        private readonly ICurrencyExchange _currencyExchange;
        public GetCurrencyCommandHandler(ICurrencyExchange currencyExchange)
        {
            _currencyExchange = currencyExchange;
        }

        public async Task<Result<GetAllCurrenciesReadModel>> Handle(GetCurrencyCommand request, CancellationToken cancellationToken)
        {
            try
            {
                var result = await _currencyExchange.GetLatestCurrencies();
                return await Result<GetAllCurrenciesReadModel>.SuccessAsync(result);
            }
            catch (Exception ex)
            {
                return await Result<GetAllCurrenciesReadModel>.FailAsync();
            }
        }
    }
}
