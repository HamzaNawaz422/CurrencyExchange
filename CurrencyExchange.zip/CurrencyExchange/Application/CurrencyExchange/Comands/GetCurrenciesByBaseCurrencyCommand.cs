﻿using Application.CurrencyExchange.Models;
using Application.Interfaces;
using Application.Wrapper;
using MediatR;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace Application.CurrencyExchange.Comands
{
    public class GetCurrenciesByBaseCurrencyCommand : IRequest<Result<GetAllCurrenciesReadModel>>
    {

        public string BaseCurrency { get; set; }


    }


    public class GetCurrenciesByBaseCurrencyCommandHandler : IRequestHandler<GetCurrenciesByBaseCurrencyCommand, Result<GetAllCurrenciesReadModel>>
    {
        private readonly ICurrencyExchange _currencyExchange;
        public GetCurrenciesByBaseCurrencyCommandHandler(ICurrencyExchange currencyExchange)
        {
            _currencyExchange = currencyExchange;
        }

        public async Task<Result<GetAllCurrenciesReadModel>> Handle(GetCurrenciesByBaseCurrencyCommand request, CancellationToken cancellationToken)
        {
            try
            {
                var result = await _currencyExchange.GetCurrenciesByBaseCurrency(request.BaseCurrency);
                return await Result<GetAllCurrenciesReadModel>.SuccessAsync(result);
            }
            catch (Exception ex)
            {
                return await Result<GetAllCurrenciesReadModel>.FailAsync();
            }
        }
    }
}
