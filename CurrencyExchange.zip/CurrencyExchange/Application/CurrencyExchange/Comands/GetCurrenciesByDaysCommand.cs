﻿using Application.CurrencyExchange.Models;
using Application.Interfaces;
using Application.Wrapper;
using MediatR;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace Application.CurrencyExchange.Comands
{
    public class GetCurrenciesByDaysCommand : IRequest<Result<GetAllCurrenciesReadModel>>
    {

        public int Days { get; set; }


    }


    public class GetCurrenciesByDaysCommandHandler : IRequestHandler<GetCurrenciesByDaysCommand, Result<GetAllCurrenciesReadModel>>
    {
        private readonly ICurrencyExchange _currencyExchange;
        public GetCurrenciesByDaysCommandHandler(ICurrencyExchange currencyExchange)
        {
            _currencyExchange = currencyExchange;
        }

        public async Task<Result<GetAllCurrenciesReadModel>> Handle(GetCurrenciesByDaysCommand request, CancellationToken cancellationToken)
        {
            try
            {
                var result = await _currencyExchange.GetCurrenciesByNDaysAgo(request.Days);
                return await Result<GetAllCurrenciesReadModel>.SuccessAsync(result);
            }
            catch (Exception ex)
            {
                return await Result<GetAllCurrenciesReadModel>.FailAsync();
            }
        }
    }
}
