﻿using Application.CurrencyExchange.Models;
using Application.Interfaces;
using Application.Wrapper;
using MediatR;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace Application.CurrencyExchange.Comands
{
    public class CurrencyConversionCommand : IRequest<Result<CurrencyConvertReadModel>>
    {
        public CurrencyConvertRequestModel requestModel { get; set; }


    }


    public class CurrencyConversionCommandHandler : IRequestHandler<CurrencyConversionCommand, Result<CurrencyConvertReadModel>>
    {
        private readonly ICurrencyExchange _currencyExchange;
        public CurrencyConversionCommandHandler(ICurrencyExchange currencyExchange)
        {
            _currencyExchange = currencyExchange;
        }

        public async Task<Result<CurrencyConvertReadModel>> Handle(CurrencyConversionCommand request, CancellationToken cancellationToken)
        {
            try
            {
                var result = await _currencyExchange.GetCurrencyConversion(request.requestModel);
                return await Result<CurrencyConvertReadModel>.SuccessAsync(result);
            }
            catch (Exception ex)
            {
                return await Result<CurrencyConvertReadModel>.FailAsync();
            }
        }
    }
}
